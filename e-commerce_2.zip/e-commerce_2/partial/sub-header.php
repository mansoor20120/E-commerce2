<div class="header-inner">
		<div class="container">
			<div class="cat-nav-head">
				<div class="row">
		<div class="col-lg-12 col-12">
							<div class="menu-area">
								<!-- Main Menu -->
								<nav class="navbar navbar-expand-lg">
									<div class="navbar-collapse">	
										<div class="nav-inner">	
											<ul class="nav main-menu menu navbar-nav">
													<li class="active"><a href="index.php">Home</a></li>
													<li><a href="product.php">Product</a></li>												
													<li><a href="">Bags<i class="ti-angle-down"></i></a>
												
												    	<ul class="dropdown">
															<li><a href="handbags.php">Handbags</a></li>
															<li><a href="wallets.php">Wallets</a></li>
															<li><a href="clutches.php">Clutches</a></li>
														</ul>
												
												    </li>
													<li><a href="">Shop<i class="ti-angle-down"></i><span class="new">New</span></a>
														<ul class="dropdown">
															<li><a href="shop-grid.php">Shop Grid</a></li>
															<li><a href="cart.php">Cart</a></li>
															<li><a href="checkout.php">Checkout</a></li>
														</ul>
													</li>
													<li><a href="pages.php">Pages</a></li>									
													<li><a href="our-blog.php">From our Blog<i class="ti-angle-down"></i></a>
														<ul class="dropdown">
															<li><a href="blog-single-sidebar.php">Blog Single Sidebar</a></li>
														</ul>
													</li>
													<li><a href="contact.php">Contact Us</a></li>
												</ul>
										</div>
									</div>
								</nav>
								<!--/ End Main Menu -->	
							</div>
		</div>
		</div>
		</div>
		</div>
		</div>