<?php
// Start the session
session_start();
if(isset($_SESSION['username'])){

    // Set session variables
$_SESSION["username"] = "green";
$_SESSION["password"] = "cat";
$_SESSION["email"] = "bag@123";
echo "Session variables are set.";


}

else{

    echo "Please Login Again To Continue";
}


?>
