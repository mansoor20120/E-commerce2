<?php 

// including connect file
include('partial/db.php');
include("partial/header.php");
include('./includes/connect.php');

// getting products

function getman() {
    global $con;

    // Query to select all items from the 'man' table
    $man = "SELECT * FROM man";
    $result_man = mysqli_query($con, $man);

    // Check if the query executed successfully
    if (!$result_man) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_man)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/men-shirts/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/men-shirts/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

// }

// displaying woman from trending item

function getwoman() {
    global $con;

    // Query to select all items from the 'man' table
    $woman = "SELECT * FROM women";
    $result_woman = mysqli_query($con, $woman);

    // Check if the query executed successfully
    if (!$result_woman) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_woman)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
<style>
    .hover-img {background: darkcyan;  }
    .hover-img:hover {transform: scale(1.2)};
    /* .hover-img:hover { transition: transform 0.3s ease-in;} */
</style>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/women-collection/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/women-collection/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

// displaying kids from trending item

function getkids() {
    global $con;

    // Query to select all items from the 'man' table
    $kid = "SELECT * FROM kid";
    $result_kid = mysqli_query($con, $kid);

    // Check if the query executed successfully
    if (!$result_kid) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_kid)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/kids-shirts/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/kids-shirts/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

// displaying accessories from trending item

function getaccessories() {
    global $con;

    // Query to select all items from the 'man' table
    $accessories = "SELECT * FROM accessories";
    $result_accessories = mysqli_query($con, $accessories);

    // Check if the query executed successfully
    if (!$result_accessories) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_accessories)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/accessories/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/accessories/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

// displaying essential from trending item

function getessential() {
    global $con;

    // Query to select all items from the 'man' table
    $essential = "SELECT * FROM essential";
    $result_essential = mysqli_query($con, $essential);

    // Check if the query executed successfully
    if (!$result_essential) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_essential)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/essential/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/essential/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}

// displaying prices from trending item

function getprices() {
    global $con;

    // Query to select all items from the 'man' table
    $prices = "SELECT * FROM prices";
    $result_prices = mysqli_query($con, $prices);

    // Check if the query executed successfully
    if (!$result_prices) {
        echo "Error: " . mysqli_error($con);
        return;
    }

    // Fetch the results and generate HTML
    while ($row = mysqli_fetch_assoc($result_prices)) {
        $id = htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8');
        $image1 = htmlspecialchars($row['image1'], ENT_QUOTES, 'UTF-8');
        $image2 = htmlspecialchars($row['image2'], ENT_QUOTES, 'UTF-8');
        $price = htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8');
?>
        <div class="col-xl-3 col-lg-4 col-md-4 col-12">
            <div class="single-product">
                <div class="product-img">
                    <a href="product-details.php?id=<?php echo $id; ?>">
                        <img class="default-img" src="images/prices/<?php echo $image1; ?>" alt="#">
                        <img class="hover-img" src="images/prices/<?php echo $image2; ?>" alt="#">
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a data-toggle="modal" data-target="#exampleModal" title="Quick View" href="#"><i class="ti-eye"></i><span>Quick Shop</span></a>
                            <a title="Wishlist" href="#"><i class="ti-heart"></i><span>Add to Wishlist</span></a>
                            <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="index.php?add_to_cart=<?php echo urlencode($id); ?>" class="btn btn-info">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="product-details.php?id=<?php echo $id; ?>"><?php echo $name; ?></a></h3>
                    <div class="product-price">
                        <span><?php echo $price; ?></span>
                    </div>
                </div>
            </div>
        </div>
<?php
    }
}
// searching products

// function search_product(){
    
// }

// get ip address function

function getIPAddress() {
    // Check if the IP is from the share internet
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    // Check if the IP is from the proxy
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // In case of multiple IPs, take the first one (which is the client IP)
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    }
    // Fallback to the remote address
    else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    return $ip;
}

// $ip = getIPAddress();
// echo 'User Real IP Address - ' . htmlspecialchars($ip, ENT_QUOTES, 'UTF-8');


// cart fuction

function cart() {

	if(isset($_GET['add_to_cart'])){

		global $con;
		
		$get_ip_add = getIPAddress(); 
		$get_product_id = $_GET['add_to_cart'];
		$man= "select * from `cartdetails` where ip_address = '$get_ip_add' and product_id = $get_product_id ";

        $result_man = mysqli_query($con, $man);
        
        $num_of_rows=mysqli_num_rows($result_man);

        if ($num_of_rows > 0){
            echo "<script>alert('This item is already present inside the cart')</script>";

            echo "<script>window.open('index.php','_self')</script>";
        }
        
        else{
            $insert_query = "insert into `cartdetails` (product_id, ip_address,quantity) values ($get_product_id, '$get_ip_add', 0)";

            $result_man= mysqli_query($con , $insert_query);
            echo "<script>alert('This item is added to the cart')</script>";

            echo "<script>window.open('index.php', '_self')</script>";
        }

	}
}

// fuction to get cart item numbers

function cart_item(){

    if(isset($_GET['add_to_cart'])){

		global $con;
		
		$get_ip_add = getIPAddress(); 
		$man= "select * from `cartdetails` where ip_address = '$get_ip_add'";

        $result_man = mysqli_query($con, $man);
        
        $count_cart_items=mysqli_num_rows($result_man);

    
        
     } else{
        
		global $con;
		
		$get_ip_add = getIPAddress(); 
		$man= "select * from `cartdetails` where ip_address = '$get_ip_add'";

        $result_man = mysqli_query($con, $man);
        
        $count_cart_items=mysqli_num_rows($result_man);
        }

        echo $count_cart_items;

        
	}

    // total price function
    function total_cart_price() {
        global $con;
    
        $get_ip_add = getIPAddress();
        $total_price = 0;
    
        // Retrieve product IDs from cart for the given IP address
        $cart_query = "SELECT product_id FROM cartdetails WHERE ip_address = ?";
        if ($stmt = mysqli_prepare($con, $cart_query)) {
            mysqli_stmt_bind_param($stmt, "s", $get_ip_add);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $product_id);
            
            // Prepare an array to hold product IDs
            $product_ids = [];
            while (mysqli_stmt_fetch($stmt)) {
                $product_ids[] = $product_id;
            }
            mysqli_stmt_close($stmt);
    
            // Check if there are any product IDs to query
            if (!empty($product_ids)) {
                // Convert array to a comma-separated list for SQL query
                $product_ids_list = implode(',', array_map('intval', $product_ids));
    
                // Create the query to get prices from all tables
                $select_products_query = "
                    SELECT price FROM (
                        SELECT price FROM man WHERE id IN ($product_ids_list)
                        UNION ALL
                        SELECT price FROM women WHERE id IN ($product_ids_list)
                        UNION ALL
                        SELECT price FROM kid WHERE id IN ($product_ids_list)
                        UNION ALL
                        SELECT price FROM accessories WHERE id IN ($product_ids_list)
                        UNION ALL
                        SELECT price FROM essential WHERE id IN ($product_ids_list)
                        UNION ALL
                        SELECT price FROM prices WHERE id IN ($product_ids_list)
                    ) AS all_prices
                ";
    
                if ($result = mysqli_query($con, $select_products_query)) {
                    while ($row_product_price = mysqli_fetch_assoc($result)) {
                        $total_price += (float) $row_product_price['price'];
                    }
                } else {
                    echo "Error fetching product prices: " . mysqli_error($con);
                }
            }
        } else {
            echo "Error fetching cart items: " . mysqli_error($con);
        }
    
        // Output the total price
        echo $total_price;
    }
    

?>