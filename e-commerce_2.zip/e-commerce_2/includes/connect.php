<?php

$con=mysqli_connect('localhost','root','','ecommerce');
if($con){

    // echo "connected....";
    // die(mysqli_error($con));

    
}
?>