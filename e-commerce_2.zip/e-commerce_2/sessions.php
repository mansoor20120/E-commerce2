<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Set session variables
$_SESSION["username"] = "green";
$_SESSION["password"] = "cat";
$_SESSION["email"] = "bag@123";
echo "Session variables are set.";
?>

</body>
</html>