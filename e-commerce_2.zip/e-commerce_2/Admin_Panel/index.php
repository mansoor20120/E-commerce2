<!DOCTYPE html>
<html lang="zxx">

<head>
  <!-- Meta Tag -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name='copyright' content=''>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Title Tag  -->
  <title>Admin Panel</title>
  <!-- Favicon -->
  <link rel="icon" type="image/png" href="images/favicon.png">
  <!-- Web Font -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

  <!-- StyleSheet -->



  <!-- Bootstrap -->
  <link rel="stylesheet" href="../css/bootstrap.css">
  <!-- Magnific Popup -->
  <link rel="stylesheet" href="../css/magnific-popup.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../css/font-awesome.css">
  <!-- Fancybox -->
  <link rel="stylesheet" href="../css/jquery.fancybox.min.css">
  <!-- Themify Icons -->
  <link rel="stylesheet" href="../css/themify-icons.css">
  <!-- Nice Select CSS -->
  <link rel="stylesheet" href="../css/niceselect.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="../css/animate.css">
  <!-- Flex Slider CSS -->
  <link rel="stylesheet" href="../css/flex-slider.min.css">
  <!-- Owl Carousel -->
  <link rel="stylesheet" href="../css/owl-carousel.css">
  <!-- Slicknav -->
  <link rel="stylesheet" href="../css/slicknav.min.css">

  <!-- Eshop StyleSheet -->
  <link rel="stylesheet" href="../css/reset.css">
  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="../css/responsive.css">

  <style>
    .admin_image {
      width: 100px;
      object-fit: contain;
    }
  </style>



</head>




<body>

  <!-- navbar -->

  <div class="container-fluid p-0">

    <!-- first child start -->

    <nav class="navbar navbar-expand-lg navbar-light bg-info">
      <div class="container-fluid">
        <img src="../images/logo.png" alt="" class="logo">

        <nav class="navbar navbar-expand-lg">

          <ul class="navbar-nav">

            <li class="nav-item">
              <a href="" class="nav-link">Welcome Guest</a>

            </li>

          </ul>



        </nav>

      </div>

    </nav>

    <!-- first child end -->


    <!-- second child start -->

    <h3 class="text-center p-2">Manage Details</h3>

    <!-- second child end -->

    <!-- third child start -->


    <div class="row">
      <div class="col-12 bg-secondary p-1 d-flex align-items-center">

        <div class="p-3">
          <a href="#"><img src="../images/accessories/access1.jpg" alt="" class="admin_image"></a>

          <p class="text-light text-center">Admin Name</p>

        </div>
        <!-- short code for making all buttons -->
        <!-- button*10>a.nav-link.text-light.bg-info.my-1 -->

        <div class="button text-center">
          <button><a href="insert_product.php" class="nav-link text-light bg-info my-1">Insert Products</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">View Products</a></button>
          <button><a href="index.php?insert_category" class="nav-link text-light bg-info my-1">Insert Categories</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">View Categories</a></button>
          <button><a href="index.php?insert_brands" class="nav-link text-light bg-info my-1">Insert Brands</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">View Brands</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">All Orders</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">All Payments</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">List Users</a></button>
          <button><a href="" class="nav-link text-light bg-info my-1">Logout</a></button>
        </div>

      </div>
    </div>



    <!-- third child end -->

    <!-- fourth child start -->

    <div class="container my-5">

    <?php
    if(isset($_GET['insert_category'])){
      include('insert_categories.php');
    }

    if(isset($_GET['insert_brands'])){
      include('insert_brands.php');
    }


    ?> 

    </div>
    <!-- fourth child end -->



    <!-- fifth child end -->

    <!-- fifth child end -->


  </div>

  <!-- bootstrape js links -->
</body>

</html>