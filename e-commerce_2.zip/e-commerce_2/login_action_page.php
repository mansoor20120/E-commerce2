<?php
session_start();
include('partial/db.php'); // Database connection setup
include('functions/common_function.php');

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Email and password are required.";
        header("Location: login.php");
        exit();
    }

    // Fetch user from database
    $stmt = $connect->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if user exists and verify password
    if ($user) {
        if (password_verify($password, $user['password'])) {
            // Password is correct, log the user in
            $_SESSION['email'] = $user['email']; // Store email in session
            $_SESSION['first_name'] = $user['first_name']; // Store first name in session
            $_SESSION['last_name'] = $user['last_name']; // Store last name in session

            // Optionally set a cookie for "Remember Me"
            if (isset($_POST['remember'])) {
                setcookie("user_email", $email, time() + (86400 * 30), "/"); // 30 days
            }

            // Redirect to welcome page or dashboard
            header("Location: welcome.php");
            exit();
        } else {
            // Invalid password
            $_SESSION['error'] = "Invalid email or password.";
            header("Location: login.php");
            exit();
        }
    } else {
        // User not found
        $_SESSION['error'] = "Invalid email or password.";
        header("Location: login.php");
        exit();
    }
} else {
    // If the form is not submitted, redirect to login
    header("Location: login.php");
    exit();
}
?>
