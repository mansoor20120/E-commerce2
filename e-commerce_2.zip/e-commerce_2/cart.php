<?php
	include("partial/db.php");
	include("partial/header.php");
	// include("partial/head.php");
	include('functions/common_function.php');
	include('./includes/connect.php');

?>
<body class="js">
	<!-- Header -->
	<header class="header shop">
		<div class="middle-inner">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-12">
						<!-- Logo -->
						<div class="logo">
							<a href="index.php"><img src="images/logo.png" alt="logo"></a>
						</div>
						<!--/ End Logo -->
						<!-- Search Form -->
						<div  class="search-top">
							<div class="top-search"><a  href="#0"><i class="ti-search"></i></a></div>
							<!-- Search Form -->
							<div  class="search-top">
								<form class="search-form">
									<input type="text" placeholder="Search here..." name="search">
									<button value="search" type="submit"><i class="ti-search"></i></button>
								</form>
							</div>
							<!--/ End Search Form -->
						</div>
						<!--/ End Search Form -->
						<div class="mobile-nav"></div>
					</div>
					<div class="col-lg-8 col-md-7 col-12">
						<div class="search-bar-top">
							<div class="search-bar">
								<select>
									<option selected="selected">All Category</option>
									<option>watch</option>
									<option>mobile</option>
									<option>kid’s item</option>
								</select>
								<form>
									<input name="search" placeholder="Search Products Here....." type="search">
									<button style="margin-top: -1px;" class="btnn"><i style="margin-top: -8px; 
									margin-left: -11px; position: absolute;" class="ti-search"></i></button>
								</form>
							</div>
						</div>
					</div>
					<div class="col-lg-2 col-md-3 col-12">
						<div class="right-bar">
							<!-- Search Form -->
							<div class="sinlge-bar">
								<a href="#" class="single-icon"><i class="fa fa-heart-o" aria-hidden="true"></i></a>
							</div>
							<div class="sinlge-bar">
								<a href="#" class="single-icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
							</div>
							<div class="sinlge-bar shopping">
								<a href="#" class="single-icon"><i class="ti-bag"></i> <span class="total-count"><?php cart_item() ?></span></a>
								<!-- Shopping Item -->
								<div class="shopping-item">
									<!-- <div class="dropdown-cart-header">
										<span>2 Items</span>
										<a href="#">View Cart</a>
									</div>
									<ul class="shopping-list">
										<li>
											<a href="#" class="remove" title="Remove this item"><i class="fa fa-remove"></i></a>
											<a class="cart-img" href="#"><img src="images/accessories/access1.jpg" alt="#"></a>
											<h4><a href="#">Woman Ring</a></h4>
											<p class="quantity">1x - <span class="amount">$99.00</span></p>
										</li>
										<li>
											<a href="#" class="remove" title="Remove this item"><i class="fa fa-remove"></i></a>
											<a class="cart-img" href="#"><img src="images/accessories/access2.jpg" alt="#"></a>
											<h4><a href="#">Woman Necklace</a></h4>
											<p class="quantity">1x - <span class="amount">$35.00</span></p>
										</li>
									</ul> -->
									<div class="bottom">
										<div class="total">
											<span>Total</span>
											<span class="total-amount"><?php total_cart_price()?></span>
										</div>
										<a href="checkout.php" class="btn animate">Checkout</a>
									</div>
								</div>
								<!--/ End Shopping Item -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Header Inner -->
		<?php
			include("partial/sub-header.php");
		?>
		<!--/ End Header Inner -->
	</header>
	<!--/ End Header -->
	
	<!-- Preloader -->
	<div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<!-- End Preloader -->
	
	
	<!-- Breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="bread-inner">
						<ul class="bread-list">
							<li><a href="index.php">Home<i class="ti-arrow-right"></i></a></li>
							<li class="active"><a href="blog-single.php">Cart</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Breadcrumbs -->
			
	<!-- Shopping Cart -->
	<div class="shopping-cart section">
		<div class="container">
			<div class="row">





				<form action="" method="POST">
				<div class="col-12">
					<!-- Shopping Summery -->
					<table class="table shopping-summery">
						<thead>
							<tr class="main-hading">
								<th>PRODUCT</th>
								<th>NAME</th>
								<th class="text-center">UNIT PRICE</th>
								<th class="text-center">QUANTITY</th>
								<th class="text-center">TOTAL</th> 
								<th class="text-center">CHECKBOX</th> 
								<th class="text-center"><i class="">REMOVE</i></th>
							</tr>
						</thead>
						<tbody>

						<!-- php code to display dynamic data -->


						<!-- for man -->

						
						<?php 
global $con;

$get_ip_add = getIPAddress();
$total_price = 0;
$cart_query = "SELECT * FROM `cartdetails` WHERE ip_address = '$get_ip_add'";
$result = mysqli_query($con, $cart_query);

while ($row = mysqli_fetch_array($result)) {
    $product_id = $row['product_id'];
    $select_products = "SELECT * FROM `man` WHERE id = '$product_id'";
    $result_products = mysqli_query($con, $select_products);
    while ($row_product_price = mysqli_fetch_array($result_products)) {
        $price = $row_product_price['price'];
        $name = $row_product_price['name'];
        $image1 = $row_product_price['image1'];

        // Calculate total price
        $total_price += $price; 
?>

<tr>
    <td class="image" data-title="No"><img src="images/men-shirts/<?php echo $image1; ?>" alt="#"></td>
    <td class="product-des" data-title="Description">
        <p class="product-name"><a href="#"></a></p>
        <p class="product-des"><?php echo $name ?></p>
    </td>
    <td class="price" data-title="Price"><span><?php echo $price ?></span></td>
    <td class="qty" data-title="Qty">
        <!-- Input Order -->
        <div class="input-group">
            <div class="button minus">
                <button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[<?php echo $product_id; ?>]">
                    <i class="ti-minus"></i>
                </button>
            </div>
            <input type="text" name="quant[<?php echo $product_id; ?>]" class="input-number" data-min="1" data-max="100" value="1">
            <div class="button plus">
                <button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[<?php echo $product_id; ?>]">
                    <i class="ti-plus"></i>
                </button>
            </div>
        </div>
        <!--/ End Input Order -->
    </td>
    <td class="total-amount" data-title="Total"><span></span></td>

    <td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>


						 <!-- For Women -->

<?php 
						
						global $con;

						$get_ip_add = getIPAddress();
						$total_price = 0;
						$cart_query = "select * from `cartdetails` where ip_address = '$get_ip_add'";
						$result = mysqli_query($con, $cart_query);
						
						while($row=mysqli_fetch_array($result)){
				
							$product_id = $row['product_id'];
							$select_products = "select * from `women` where id = '$product_id'";
							$result_products = mysqli_query($con, $select_products);
							while($row_product_price=mysqli_fetch_array($result_products)){
				
								$product_price = array($row_product_price['price']);

								$price = $row_product_price['price'];
								$name = $row_product_price['name'];
								$image1= $row_product_price['image1'];

								$product_values = array_sum($product_price);
								$total_price+=$product_values;
				
						
						
						?>

							<tr>
								<td class="image" data-title="No"><img src="images/women-shirts/<?php echo $image1; ?>" alt="#"></td>
								<td class="product-des" data-title="Description">
									<p class="product-name"><a href="#"></a></p>
									<p class="product-des"><?php echo $name ?></p>
								</td>
								<td class="price" data-title="Price"><span><?php echo $price ?></span></td>
								<td class="qty" data-title="Qty"><!-- Input Order -->
									<div class="input-group">
										<div class="button minus">
											<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												<i class="ti-minus"></i>
											</button>
										</div>
										<input type="text" name="quant[1]" class="input-number"  data-min="<?php echo $quantity ?>" data-max="100" value="1">
										<div class="button plus">
											<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
												<i class="ti-plus"></i>
											</button>
										</div>
									</div>
									<!--/ End Input Order -->
								</td>
								<td class="total-amount" data-title="Total"><span></span></td>
								<!-- <td class="action" data-title="Remove"><a href="#"><i class="ti-trash remove-icon"></i></a></td> -->

								<td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>
							
						 <!-- For Kids -->

<?php 
						
						global $con;

						$get_ip_add = getIPAddress();
						$total_price = 0;
						$cart_query = "select * from `cartdetails` where ip_address = '$get_ip_add'";
						$result = mysqli_query($con, $cart_query);
						
						while($row=mysqli_fetch_array($result)){
				
							$product_id = $row['product_id'];
							$select_products = "select * from `kid` where id = '$product_id'";
							$result_products = mysqli_query($con, $select_products);
							while($row_product_price=mysqli_fetch_array($result_products)){
				
								$product_price = array($row_product_price['price']);

								$price = $row_product_price['price'];
								$name = $row_product_price['name'];
								$image1= $row_product_price['image1'];

								$product_values = array_sum($product_price);
								$total_price+=$product_values;
				
						
						
						?>

							<tr>
								<td class="image" data-title="No"><img src="images/kids-shirts/<?php echo $image1; ?>" alt="#"></td>
								<td class="product-des" data-title="Description">
									<p class="product-name"><a href="#"></a></p>
									<p class="product-des"><?php echo $name ?></p>
								</td>
								<td class="price" data-title="Price"><span><?php echo $price ?></span></td>
								<td class="qty" data-title="Qty"><!-- Input Order -->
									<div class="input-group">
										<div class="button minus">
											<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												<i class="ti-minus"></i>
											</button>
										</div>
										<input type="text" name="quant[1]" class="input-number"  data-min="<?php echo $quantity ?>" data-max="100" value="1">
										<div class="button plus">
											<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
												<i class="ti-plus"></i>
											</button>
										</div>
									</div>
									<!--/ End Input Order -->
								</td>
								<td class="total-amount" data-title="Total"><span></span></td>
								<!-- <td class="action" data-title="Remove"><a href="#"><i class="ti-trash remove-icon"></i></a></td> -->

								<td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>
							
						 <!-- For Accessories -->

<?php 
						
						global $con;

						$get_ip_add = getIPAddress();
						$total_price = 0;
						$cart_query = "select * from `cartdetails` where ip_address = '$get_ip_add'";
						$result = mysqli_query($con, $cart_query);
						
						while($row=mysqli_fetch_array($result)){
				
							$product_id = $row['product_id'];
							$select_products = "select * from `accessories` where id = '$product_id'";
							$result_products = mysqli_query($con, $select_products);
							while($row_product_price=mysqli_fetch_array($result_products)){
				
								$product_price = array($row_product_price['price']);

								$price = $row_product_price['price'];
								$name = $row_product_price['name'];
								$image1= $row_product_price['image1'];

								$product_values = array_sum($product_price);
								$total_price+=$product_values;
				
						
						
						?>

							<tr>
								<td class="image" data-title="No"><img src="images/accessories/<?php echo $image1; ?>" alt="#"></td>
								<td class="product-des" data-title="Description">
									<p class="product-name"><a href="#"></a></p>
									<p class="product-des"><?php echo $name ?></p>
								</td>
								<td class="price" data-title="Price"><span><?php echo $price ?></span></td>
								<td class="qty" data-title="Qty"><!-- Input Order -->
									<div class="input-group">
										<div class="button minus">
											<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												<i class="ti-minus"></i>
											</button>
										</div>
										<input type="text" name="quant[1]" class="input-number"  data-min="<?php echo $quantity ?>" data-max="100" value="1">
										<div class="button plus">
											<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
												<i class="ti-plus"></i>
											</button>
										</div>
									</div>
									<!--/ End Input Order -->
								</td>
								<td class="total-amount" data-title="Total"><span></span></td>
								<!-- <td class="action" data-title="Remove"><a href="#"><i class="ti-trash remove-icon"></i></a></td> -->

								<td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>							
						 <!-- For Essential -->

<?php 
						
						global $con;

						$get_ip_add = getIPAddress();
						$total_price = 0;
						$cart_query = "select * from `cartdetails` where ip_address = '$get_ip_add'";
						$result = mysqli_query($con, $cart_query);
						
						while($row=mysqli_fetch_array($result)){
				
							$product_id = $row['product_id'];
							$select_products = "select * from `essential` where id = '$product_id'";
							$result_products = mysqli_query($con, $select_products);
							while($row_product_price=mysqli_fetch_array($result_products)){
				
								$product_price = array($row_product_price['price']);

								$price = $row_product_price['price'];
								$name = $row_product_price['name'];
								$image1= $row_product_price['image1'];

								$product_values = array_sum($product_price);
								$total_price+=$product_values;
				
						
						
						?>

							<tr>
								<td class="image" data-title="No"><img src="images/essential/<?php echo $image1; ?>" alt="#"></td>
								<td class="product-des" data-title="Description">
									<p class="product-name"><a href="#"></a></p>
									<p class="product-des"><?php echo $name ?></p>
								</td>
								<td class="price" data-title="Price"><span><?php echo $price ?></span></td>
								<td class="qty" data-title="Qty"><!-- Input Order -->
									<div class="input-group">
										<div class="button minus">
											<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												<i class="ti-minus"></i>
											</button>
										</div>
										<input type="text" name="quant[1]" class="input-number"  data-min="<?php echo $quantity ?>" data-max="100" value="1">
										<div class="button plus">
											<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
												<i class="ti-plus"></i>
											</button>
										</div>
									</div>
									<!--/ End Input Order -->
								</td>
								<td class="total-amount" data-title="Total"><span></span></td>
								<!-- <td class="action" data-title="Remove"><a href="#"><i class="ti-trash remove-icon"></i></a></td> -->

								<td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>							
						 <!-- For Prices -->

<?php 
						
						global $con;

						$get_ip_add = getIPAddress();
						$total_price = 0;
						$cart_query = "select * from `cartdetails` where ip_address = '$get_ip_add'";
						$result = mysqli_query($con, $cart_query);
						
						while($row=mysqli_fetch_array($result)){
				
							$product_id = $row['product_id'];
							$select_products = "select * from `prices` where id = '$product_id'";
							$result_products = mysqli_query($con, $select_products);
							while($row_product_price=mysqli_fetch_array($result_products)){
				
								$product_price = array($row_product_price['price']);

								$price = $row_product_price['price'];
								$name = $row_product_price['name'];
								$image1= $row_product_price['image1'];

								$product_values = array_sum($product_price);
								$total_price+=$product_values;
				
						
						
						?>

							<tr>
								<td class="image" data-title="No"><img src="images/prices/<?php echo $image1; ?>" alt="#"></td>
								<td class="product-des" data-title="Description">
									<p class="product-name"><a href="#"></a></p>
									<p class="product-des"><?php echo $name ?></p>
								</td>
								<td class="price" data-title="Price"><span><?php echo $price ?></span></td>
								<td class="qty" data-title="Qty"><!-- Input Order -->
									<div class="input-group">
										<div class="button minus">
											<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												<i class="ti-minus"></i>
											</button>
										</div>
										<input type="text" name="quant[1]" class="input-number"  data-min="<?php echo $quantity ?>" data-max="100" value="1">
										<div class="button plus">
											<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
												<i class="ti-plus"></i>
											</button>
										</div>
									</div>
									<!--/ End Input Order -->
								</td>
								<td class="total-amount" data-title="Total"><span></span></td>
								<!-- <td class="action" data-title="Remove"><a href="#"><i class="ti-trash remove-icon"></i></a></td> -->

								<td>
        <form action="cart.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <button type="submit" class="action" name="remove_cart" style="background: none; border: none; padding: 0; cursor: pointer;">
                <i class="fas fa-trash-alt" style="font-size: 20px; color: red;"></i>
            </button>
        </form>
    </td>
</tr>

<?php 

if (isset($_POST['remove_cart'])) {
    $product_id = $_POST['product_id'];
    $remove_query = "DELETE FROM `cartdetails` WHERE product_id = '$product_id' AND ip_address = '$get_ip_add'";
    $result = mysqli_query($con, $remove_query);

	echo "<script>window.open('cart.php', '_self')</script>";

    // Redirect or refresh the cart page after removal
}

    }
}
?>							
							
						</tbody>
					</table>
					<!--/ End Shopping Summery -->
				</div>
				</form>
				

				<!-- funtion to remove cart item -->
			



			</div>
			<div class="row">
				<div class="col-12">
					<!-- Total Amount -->
					<div class="total-amount">
						<div class="row">
							<div class="col-lg-8 col-md-5 col-12">
								<div class="left">
									<div class="coupon">
										<form action="#" target="_blank">
											<input name="Coupon" placeholder="Enter Your Coupon">
											<button class="btn">Apply</button>
										</form>
									</div>
									<div class="checkbox">
										<label class="checkbox-inline" for="2"><input name="news" id="2" type="checkbox"> Shipping (+10$)</label>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-7 col-12">
								<div class="right">
									<ul>
										<li>Cart Subtotal<span><?php echo $total_price ?></span></li>
										<li>Shipping<span>Free</span></li>
										<li>You Save<span>$20.00</span></li>
										<li class="last">You Pay<span>$310.00</span></li>
									</ul>
									<div class="button5">
										<a href="#" class="btn">Checkout</a>
										<a href="index.php" class="btn">Continue shopping</a>

									</div>
								</div>
							</div>
						</div>
					</div>
					<!--/ End Total Amount -->
				</div>
			</div>
		</div>
	</div>
	<!--/ End Shopping Cart -->
			
	<!-- Start Shop Services Area  -->
	<section class="shop-services section">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-rocket"></i>
						<h4>Free shiping</h4>
						<p>Orders over $100</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-reload"></i>
						<h4>Free Return</h4>
						<p>Within 30 days returns</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-lock"></i>
						<h4>Sucure Payment</h4>
						<p>100% secure payment</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-tag"></i>
						<h4>Best Peice</h4>
						<p>Guaranteed price</p>
					</div>
					<!-- End Single Service -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Newsletter -->
	
	<!-- Start Shop Newsletter  -->
	<section class="shop-newsletter section">
		<div class="container">
			<div class="inner-top">
				<div class="row">
					<div class="col-lg-8 offset-lg-2 col-12">
						<!-- Start Newsletter Inner -->
						<div class="inner">
							<h4>Newsletter</h4>
							<p> Subscribe to our newsletter and get <span>10%</span> off your first purchase</p>
							<form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
								<input name="EMAIL" placeholder="Your email address" required="" type="email">
								<button class="btn">Subscribe</button>
							</form>
						</div>
						<!-- End Newsletter Inner -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Newsletter -->
	
	
	
	<!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close" aria-hidden="true"></span></button>
                    </div>
                    <div class="modal-body">
                        <div class="row no-gutters">
                            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <!-- Product Slider -->
									<div class="product-gallery">
										<div class="quickview-slider-active">
											<div class="single-slider">
												<img src="images/modal1.jpg" alt="#">
											</div>
											<div class="single-slider">
												<img src="images/modal2.jpg" alt="#">
											</div>
											<div class="single-slider">
												<img src="images/modal3.jpg" alt="#">
											</div>
											<div class="single-slider">
												<img src="images/modal4.jpg" alt="#">
											</div>
										</div>
									</div>
								<!-- End Product slider -->
                            </div>
                            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                <div class="quickview-content">
                                    <h2>Flared Shift Dress</h2>
                                    <div class="quickview-ratting-review">
                                        <div class="quickview-ratting-wrap">
                                            <div class="quickview-ratting">
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="yellow fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                            <a href="#"> (1 customer review)</a>
                                        </div>
                                        <div class="quickview-stock">
                                            <span><i class="fa fa-check-circle-o"></i> in stock</span>
                                        </div>
                                    </div>
                                    <h3>$29.00</h3>
                                    <div class="quickview-peragraph">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam in quos qui nemo ipsum numquam.</p>
                                    </div>
									<div class="size">
										<div class="row">
											<div class="col-lg-6 col-12">
												<h5 class="title">Size</h5>
												<select>
													<option selected="selected">s</option>
													<option>m</option>
													<option>l</option>
													<option>xl</option>
												</select>
											</div>
											<div class="col-lg-6 col-12">
												<h5 class="title">Color</h5>
												<select>
													<option selected="selected">orange</option>
													<option>purple</option>
													<option>black</option>
													<option>pink</option>
												</select>
											</div>
										</div>
									</div>
                                    <div class="quantity">
										<!-- Input Order -->
										<div class="input-group">
											<div class="button minus">
												<button type="button" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
													<i class="ti-minus"></i>
												</button>
											</div>
											<input type="text" name="quant[1]" class="input-number"  data-min="1" data-max="1000" value="1">
											<div class="button plus">
												<button type="button" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">
													<i class="ti-plus"></i>
												</button>
											</div>
										</div>
										<!--/ End Input Order -->
									</div>
									<div class="add-to-cart">
										<a href="#" class="btn">Add to cart</a>
										<a href="#" class="btn min"><i class="ti-heart"></i></a>
										<a href="#" class="btn min"><i class="fa fa-compress"></i></a>
									</div>
                                    <div class="default-social">
										<h4 class="share-now">Share:</h4>
                                        <ul>
                                            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a class="youtube" href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                            <li><a class="dribbble" href="#"><i class="fa fa-google-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal end -->
	
	<!-- Start Footer Area -->
	<?php
	
	include("partial/footer.php");
	?>

	<!-- /End Footer Area -->
	
	<!-- Jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<!-- Popper JS -->
	<script src="js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Color JS -->
	<script src="js/colors.js"></script>
	<!-- Slicknav JS -->
	<script src="js/slicknav.min.js"></script>
	<!-- Owl Carousel JS -->
	<script src="js/owl-carousel.js"></script>
	<!-- Magnific Popup JS -->
	<script src="js/magnific-popup.js"></script>
	<!-- Fancybox JS -->
	<script src="js/facnybox.min.js"></script>
	<!-- Waypoints JS -->
	<script src="js/waypoints.min.js"></script>
	<!-- Countdown JS -->
	<script src="js/finalcountdown.min.js"></script>
	<!-- Nice Select JS -->
	<script src="js/nicesellect.js"></script>
	<!-- Ytplayer JS -->
	<script src="js/ytplayer.min.js"></script>
	<!-- Flex Slider JS -->
	<script src="js/flex-slider.js"></script>
	<!-- ScrollUp JS -->
	<script src="js/scrollup.js"></script>
	<!-- Onepage Nav JS -->
	<script src="js/onepage-nav.min.js"></script>
	<!-- Easing JS -->
	<script src="js/easing.js"></script>
	<!-- Active JS -->
	<script src="js/active.js"></script>
</body>
</html>