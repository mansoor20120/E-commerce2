<?php
session_start();
include('partial/db.php'); // Database connection setup
include('functions/common_function.php');

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['psw']);
    $password_repeat = trim($_POST['psw-repeat']);

    // Validate input
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($password_repeat)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: register.php");
        exit();
    }

    if ($password !== $password_repeat) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: register.php");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Insert into database
        $stmt = $connect->prepare("INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$first_name, $last_name, $email, $hashed_password])) {
            // Registration successful
            $_SESSION['email'] = $email; // Store email in session
            $_SESSION['first_name'] = $first_name; // Store first name in session
            $_SESSION['last_name'] = $last_name; // Store last name in session
            $_SESSION['success'] = "Registration successful. You are now logged in.";
            header("Location: welcome.php"); // Redirect to a welcome page
            exit();
        } else {
            $_SESSION['error'] = "Registration failed. Please try again.";
            header("Location: register.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Database error: " . $e->getMessage();
        header("Location: register.php");
        exit();
    }
}
?>
