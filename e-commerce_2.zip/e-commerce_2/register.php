<?php
session_start();
include('partial/db.php');
include('partial/header.php');
?>

<div class="container">
  <h1>Register</h1>
  <p>Please fill in this form to create an account.</p>
  <hr>

  <?php
  // Display error or success messages
  if (isset($_SESSION['error'])) {
      echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
      unset($_SESSION['error']);
  }
  if (isset($_SESSION['success'])) {
      echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
      unset($_SESSION['success']);
  }
  ?>

  <form action="action_page.php" method="post">
    <label for="first_name"><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="first_name" id="first_name" required>

    <label for="last_name"><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="last_name" id="last_name" required>

    <label for="email"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" id="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required>
    <hr>

    <p>By creating an account you agree to our <a href="terms.php">Terms & Privacy</a>.</p>
    <button type="submit" class="registerbtn">Register</button>
  </form>

  <div class="container signin">
    <p>Already have an account? <a href="login.php">Sign in</a>.</p>
  </div>
</div>
